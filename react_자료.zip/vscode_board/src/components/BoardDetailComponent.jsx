import BoardService from "../service/BoardService";
import React, { Component, useEffect, useState } from 'react';
import { useNavigate, useParams } from "react-router-dom";

function BoardDetailComponent(){

    //const [seq,setSeq] = useState({});
    const [board,setBoard] = useState({});

    //버전 5는 Route props으로 match, location, history를 사용
    //react-router-dom 버전 6부터 useParams, useLocation, useHistory :함수형 component사용해야함
    let {seq} = useParams();// /detail/:seq로 요청했을때 seq 파라미터를 받는다.
    
    //경로 변경을 위한 객체: usenavigate(요청경로,replace:true/false)
    //                     replace:true면 현재페이지 대체한다는 의미 : 뒤로가기시 이전 페이지 X
    //                      -> 로그인 후 메인페이지 이동시, 폼전송후 리스트페이지로 이동시
    //                     replace:false면 새페이지가 브라우저기록에 추가, 뒤로가기시 이전 페이지 O 
    let navigate = useNavigate();

    useEffect(()=>{
        BoardService.getDetailBoard(seq).then( res => {
            setBoard(res.data.dto);
        });    
    },[]);

    let deleteBoard = (seq) => {
        if(window.confirm("정말삭제하시겠습니까?")){
            BoardService.deleteBoard(seq).then( res => {
                navigate("/board");
            });
        }
        
    }

    return(
        <div>
             <h2 className="text-center">Boards Detail</h2>
            <table className="table table-striped" border="1">
                <tbody>
                    <tr>
                        <th>번호</th>
                        <td>{board.seq}</td>
                    </tr>
                    <tr>
                        <th>작성일</th>
                        <td>{board.regdate}</td>
                    </tr>
                    <tr>
                        <th>작성자</th>
                        <td>{board.id}</td>
                    </tr>
                    <tr>
                        <th>제목</th>
                        <td>{board.title}</td>
                    </tr>
                    <tr>
                        <th>내용</th>
                        <td><textarea className="form-control" rows={15} cols={70} 
                                      value={board.content} readOnly="readOnly"></textarea></td>
                    </tr>
                    <tr>
                        <td colSpan={2}>
                            <button className="btn btn-info" type="button" onClick={() =>navigate(`/updateform/${board.seq}`,{replace:true})}>수정</button>&nbsp; 
                            <button className="btn btn-info" onClick={() =>{deleteBoard(board.seq);}}>삭제</button>&nbsp; 
                            <button className="btn btn-info" onClick={() =>navigate(`/board`,{replace:true})}>목록</button>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
    );
}
/*
class BoardDetailComponent extends Component{
    constructor(props){
        super(props);

        this.state = {
            seq : this.props.match.params.seq,
            board: {}
        }
    }

    componentDidMount() {
        BoardService.getDetailBoard(this.state.seq).then( res => {
            this.setState({board: res.data.dto});
        });
    }

    render(){
        return (
            <div>
                <table>
                    <tr>
                        <th>번호</th>
                        <td>{this.state.board.seq}</td>
                    </tr>
                </table>
            </div>
        );
    }
}
*/
export default BoardDetailComponent;