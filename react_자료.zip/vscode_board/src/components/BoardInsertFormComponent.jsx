import BoardService from "../service/BoardService";
import React, { Component, useEffect, useState } from 'react';
import { useNavigate, useParams } from "react-router-dom";



function BoardInsertFormComponent(){
    //const [seq,setSeq] = useState({});
    const [board,setBoard] = useState({});
    const [count, setCount] = useState();
    //버전 5는 Route props으로 match, location, history를 사용
    //react-router-dom 버전 6부터 useParams, useLocation, useHistory :함수형 component사용해야함
    let {seq} = useParams();
    let navigate = useNavigate();

   const onChange = (e) => {
       const {name, value} = e.target;
       console.log(name+":"+value);
       if(name==="id"){
        setBoard({
                  'id':value,
                  'title':board.title,
                  'content':board.content,
                  'regdate':board.regdate   
                })
        }
       if(name==="title"){
            setBoard({
                      'id':board.id,
                      'title':value,
                      'content':board.content,
                      'regdate':board.regdate   
                    })
        }
        if(name==="content"){
            setBoard({
                      'id':board.id,
                      'title':board.title,
                      'content':value,
                      'regdate':board.regdate   
                    })
        }
       console.log("제목:"+board.title);
   }

   //form 전송시 onSubmit에 함수 실행으로 구현한다.
   const insertHandler = (e) => {
        e.preventDefault();
        BoardService.insertBoard(board).then( res => {
        // res는 서버로부터 응답정보를 받는다. data는 전달된 값
           console.log("글추가개수:"+res.data.count); 
            navigate('/board');
        });    
   }
    return(
        <div>
             <h2 className="text-center">Boards Add</h2>
            <form  onSubmit={insertHandler}>
                <table className="table table-striped" border="1">
                    <tbody>
                    <tr>
                        <th>작성자</th>        
                        {/* {조건||출력내용} : board.id가 null,undefined,등일때 ""출력 , {조건&&출력내용} : board.id가 값이 있을경우만 출력  */}
                        <td><input className="form-control" type="text" name="id" onChange={onChange} value={board.id||""}/></td>
                    </tr>
                    <tr>
                        <th>제목</th>
                        <td><input className="form-control" type="text" name="title" onChange={onChange} value={board.title||""} /></td>
                    </tr>
                    <tr>
                        <th>내용</th>
                        <td><textarea className="form-control" name="content" onChange={onChange} rows={15} cols={70} value={board.content||""}></textarea></td>
                    </tr>
                    <tr>
                        <td colSpan={2}>
                           <button className="btn btn-info"  type="submit">글추가</button>
                        </td>
                    </tr>
                    </tbody>
                </table>
            </form>
        </div>
    );
}



export default BoardInsertFormComponent;