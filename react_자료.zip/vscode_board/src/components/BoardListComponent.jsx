import React, { Component, useEffect, useState } from 'react';
import BoardService from '../service/BoardService';
import { useNavigate } from "react-router-dom";
import {Link} from "react-router-dom";

function BoardListComponent(){

    const [boards, setBoards] = useState([]);
    
    useEffect(()=>{
        BoardService.getBoards().then((res) => {
            console.log("글목록보여줘");
            //글목록 List[dto{id:hk,title:제목..},dto{id:hk,title:제목..}..] --> JS에서는 배열로 받음
            setBoards(res.data.list);
        });

    },[])

    //react-route-dom v5에서는 useHistory 사용
    //                v6에서는 useNavigate 사용 : 함수형 component에서 사용함
    //Link VS Navigate: 현재 상황에서는 Link를 사용하는 것이 적합함
    //                  Link는 새로고침을 하지 않고 이동-> SPA에 적합함, 직관적임
    //                  단순히 페이지 이동을 할경우 Link를 사용하고, 
    //                  추가적인 제어가 필요할 경우 navigate를 사용한다.
    let navigate = useNavigate();
    
    return(
        <div>
            <h2 className="text-center">Boards List</h2>
            <div className ="row">
                <table className="table table-striped" border="1">
                    <thead>
                        <tr className="table-info text-center">
                            <th className='col-1'>글 번호</th>
                            <th className='col-6'>타이틀 </th>
                            <th className='col-2'>작성자 </th>
                            <th className='col-2'>작성일 </th>
                        </tr>
                    </thead>
                    <tbody>
                        {
                            boards.map(
                                board => 
                                <tr key = {board.seq} className="text-center" >
                                    <td> {board.seq} </td>
                                    {/* <td> <a onClick = {() => navigate(`/detail/${board.seq}`)}>{board.title}</a> </td>  */}
                                    <td><Link to={`/detail/${board.seq}`}>{board.title}</Link></td>
                                    <td> {board.id} </td>
                                    <td> {board.regdate} </td>
                                </tr>
                            )
                        }
                    </tbody>
                    <tfoot>
                        <tr>
                            <td colSpan={4}>
                                <Link to="/insert" className='btn btn-primary'>글추가</Link>
                            </td>
                        </tr>
                    </tfoot>
                </table>
            </div>
        </div>  
    );
}


/*
class BoardListComponent extends Component{
    
    constructor(props){
        super(props);
        this.state = {
            boards:[]
        }
        this.createBoard = this.createBoard.bind(this);

    }

    componentDidMount(){
        console.log("BoardListComponent로 이동");
        BoardService.getBoards().then((res) => {
            this.setState({ boards: res.data.list});
        });
    }
    createBoard() {
        this.props.history.push('/create-board/');
    }

    readBoard(seq) {
      
        
       // this.props.history.push('/detail/'+seq);
    }

    render(){
        let navigate = useNavigate();
        return(
            <div>
            <h2 className="text-center">Boards List</h2>
            <div className ="row">
                <table className="table table-striped table-bordered">
                    <thead>
                        <tr>
                            <th>글 번호</th>
                            <th>타이틀 </th>
                            <th>작성자 </th>
                            <th>작성일 </th>
                        </tr>
                    </thead>
                    <tbody>
                        {
                            this.state.boards.map(
                                board => 
                                <tr key = {board.seq}>
                                    <td> {board.seq} </td>
                                    <td> <a onClick = {() => navigate(`/detail/${board.seq}`)}>{board.title}</a> </td> 
                                    <td> {board.id} </td>
                                    <td> {board.regdate} </td>
                                </tr>
                            )
                        }
                    </tbody>
                </table>
            </div>
        </div>  
        );
        
    }

}
*/
export default BoardListComponent;
