import BoardService from "../service/BoardService";
import React, { Component, useEffect, useState } from 'react';
import { useNavigate, useParams } from "react-router-dom";



function BoardUpdateFormComponent(){
    //const [seq,setSeq] = useState({});
    const [board,setBoard] = useState({});
    const [count, setCount] = useState();
    //버전 5는 Route props으로 match, location, history를 사용
    //react-router-dom 버전 6부터 useParams, useLocation, useHistory :함수형 component사용해야함
    let {seq} = useParams(); // 여러개일경우 let {seq,id} = userParams()
    let navigate = useNavigate();

    //useEffect는 렌더링 되는 순간 반복적으로 계속 실행이 된다. 
    //반복실행을 해제하고 싶으면, useEffect(()=>{},[]) 두번째 인자값에 빈배열을 선언하면 된다.
    //원할때만 useEffect를 실행하고 싶으면useEffect(()=>{},[test]) 
    // ---> 두번째 인자값에 const [test,setTest]=useState()값을 넣어주고 그값이 변경되면 실행된다.
    useEffect(()=>{
        BoardService.getDetailBoard(seq).then( res => {
            setBoard(res.data.dto);//서버에서 응답한 정보는 Json이라 setBoard에 바로 전달시키면 된다.
        });    
        console.log("useEffect실행");
    },[]);

   const onChange = (e) => {
       const {name, value} = e.target;
       console.log(name+":"+value);
       if(name==="title"){
            setBoard({'seq':board.seq,
                      'id':board.id,
                      'title':value,
                      'content':board.content,
                      'regdate':board.regdate   
                    })
        }
        if(name==="content"){
            setBoard({'seq':board.seq,
                      'id':board.id,
                      'title':board.title,
                      'content':value,
                      'regdate':board.regdate   
                    })
        }
       console.log("제목:"+board.title);
   }

   const updateHandler = (e) => {
        e.preventDefault();
        BoardService.updateBoard(board).then( res => {
           console.log(res.data.seq)
            navigate('/detail/'+res.data.seq);
        });    
   }
    return(
        <div>
             <h2 className="text-center">Boards Update</h2>
            <form  onSubmit={updateHandler}>
                <input type="hidden" name="seq" value={board.seq}/>
                <table className="table table-striped" border="1">
                    <tbody>
                        <tr>
                            <th>번호</th>
                            <td>{board.seq}</td>
                        </tr>
                        <tr>
                            <th>작성일</th>
                            <td>{board.regdate}</td>
                        </tr>
                        <tr>
                            <th>작성자</th>
                            <td>{board.id}</td>
                        </tr>
                        <tr>
                            <th>제목</th>
                            <td><input className="form-control" type="text" name="title" onChange={onChange} value={board.title||""} /></td>
                        </tr>
                        <tr>
                            <th>내용</th>
                            <td><textarea className="form-control" name="content" onChange={onChange} rows={15} cols={70} value={board.content||""}></textarea></td>
                        </tr>
                        <tr>
                            <td colSpan={2}>
                            <input className="btn btn-info" type="submit" value="수정"/>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </form>
        </div>
    );
}



export default BoardUpdateFormComponent;