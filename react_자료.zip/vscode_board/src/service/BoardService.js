import axios from "axios";

const BoardList_URL='/boardlist';

class BoardService{
    getBoards(){
        console.log("service:boardlist요청");
        return axios.get(BoardList_URL);
    }

    getDetailBoard(seq){
        console.log("service:detail요청:"+seq);
        return axios.get('/detail/'+seq);
    }

    insertBoard(dto){
        console.log("service:insert요청:"+dto.title);

        //post방식으로 전송할때 post메서드에 매개변수는 3번째에 파라미터값을 설정해야 전달이 된다.(두번째는 null로 비워둔다)
        return axios.post("/insert",null,{params:{
            title:dto.title,
            content:dto.content,
            id:dto.id
        }});
    }
    
    updateBoard(dto){
        console.log("service:update요청:"+dto.title);

        //post방식으로 전송할때 post메서드에 매개변수는 3번째에 파라미터값을 설정해야 전달이 된다.(두번째는 null로 비워둔다)
        return axios.put("/update",null,{params:{
            title:dto.title,
            content:dto.content,
            seq:dto.seq
        }});
    }

    deleteBoard(seq){
        console.log("service:delete요청:"+seq);
        return axios.delete('/delete/'+seq);
    }
}

export default new BoardService();