
import './App.css';
import {useEffect, useState} from "react";
import { tab } from '@testing-library/user-event/dist/tab';
import {BrowserRouter as Router, Route, Link, Routes } from 'react-router-dom';
import BoardListComponent from './components/BoardListComponent';
import BoardDetailComponent from './components/BoardDetailComponent';
import BoardUpdateFormComponent from './components/BoardUpdateFormComponent';
import BoardInsertFormComponent from './components/BoardInsertFormComponent';

function App() {
  
  return (
    <Router>
      <div className='container'>
        <div><Link to='/board' className='btn btn-primary'>글목록</Link></div>
        <Routes>  
          {/* 파라미터 여러개일경우: path='/board/:seq/:id/:name */}
          <Route  path='/board' element={<BoardListComponent />}  ></Route>
          <Route  path='/insert' element={<BoardInsertFormComponent />}  ></Route>
          <Route  path='/detail/:seq' element={<BoardDetailComponent />}  ></Route> 
          <Route  path='/updateform/:seq' element={<BoardUpdateFormComponent />}  ></Route> 
        </Routes>
      </div>
    </Router>

  )
 
}

export default App;
