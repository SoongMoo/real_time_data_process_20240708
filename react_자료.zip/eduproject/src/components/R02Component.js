import React, { Component } from 'react';

//컴포넌트란? 페이지를 표현하는 최소 단위
//props 객체는 상위에서 하위 컴포넌트로 값을 전달할 때 사용
class R02Component extends Component {

    render() {         // {name:값,name2:값}
        //구조분해할당 문법
        const {name,children} = this.props;//상위컴포넌트에서 name란 이름으로 값전달
        
        return (
            <div>
                <h2>컴포넌트1:{name}</h2>
                <h2>컴포넌트의 자식값:{children}</h2>
            </div>
        );
    }
}

//함수형 컴포넌트
const R02ComponentFunc = (props) => {
    return (
        <div>
            <h2>컴포넌트1:{props.name}</h2>
            <h2>컴포넌트의 자식값:{props.children}</h2>
        </div>
    );
};

class R02ComponentState extends Component {

    //state 를 이용해서 값의 상태를 관리한다.
    //클래스형 컴포넌트에서 state 선언방법
    // 1. 생성자함수를 이용하는 방법
    constructor(props){
        super(props);
        this.state={
            name:0
        }
    }
    
    // 2.필드 선언 방식
    state ={
        number1:1
    }


    //* render()는 렌더링을 실행하는 메서드-> 내부에 변수나 함수를 선언하면
    // 렌더링 될때마다 실행된다.--> 변경되지 않는 변수나 함수를 선언하면 성능상 안좋음
    render() {
        // let val=0;
        return (
            <div>
                <h2>클래스형:state</h2>
                <input type="text" value={this.state.name}/>
                {/* <button onClick={()=>{val+1}}>클릭</button> */}
                {/* <button onClick={()=>{this.state.name+=1}}>클릭</button> */}
                <button onClick={()=>{this.setState({name:this.state.name+1})}}>클릭</button>
            </div>
        );
    }
}

export default R02Component;
export {R02ComponentFunc,R02ComponentState}; //{comp1,comp2..}