import React, { Fragment } from 'react';

// snippets : rcs(함수형자동생성), rcc(클래스형자동생성)
const R01Jsx = () => {
    
    const name="리액트";

    return (
        // 반드시 하나의 엘리먼트로 감싸야 한다.
        // <div>
        //     <h1>리액트 안녕~~</h1>
        //     <h2>잘 작동할까?</h2>
        // </div>
        // <Fragment>
        //     <h1>리액트 안녕~~</h1>
        //     <h2>잘 작동할까?</h2> 
        // </Fragment>
        <>
            <h1>리액트</h1>
            <h2>안녕 {name}</h2>
        </>
    );
};

//다른 JS파일에서 import할 수 있도록 정의
//default 값은 필수 작성 요소임
export default R01Jsx; 
