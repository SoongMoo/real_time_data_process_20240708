import React, { useEffect, useState, Component } from 'react';

//Hooks: 클래스형 컴포넌트에서 사용하던 기능들을
//       함수형 컴포넌트에서 사용할 수 있도록 기능을 추가
//       useState(), useEffect(), userRef ..
const R05Hooks = () => {

    const [name, setName]=useState("");
    const [displayName,setDisplayName] = useState("");

    const displayNameFunc=()=>{
        setDisplayName(name);
    }

    //useEffect는 페이지 마운트 및 업데이트시 실행
    useEffect(()=>{
        console.log("마운트 및 업데이트시 실행");
    },[displayName]);//- 2번째 파리미터에 []를 선언하면 
                     //  마운트시 최초 한번만 실행된다.
                     //- [state명]선언하면 해당 state가 
                     //  변경될때만 실행
    return (
        <div>
            <h1>Hooks</h1>
            <input type="text" 
                onChange={(e)=>{setName(e.target.value)}}/>
            {/* <span>{name}</span> */}
            <button onClick={displayNameFunc}>확인</button>
            <span>{displayName}</span>
        </div>
    );
};

class R06ClassComponent extends Component {

    state = {
        message:"초기값"
    }

    //클래스형컴포넌트에서 useEffect와 동일한 기능 구현
    //리액트의 라이프 사이클
    componentDidMount(){
        console.log("컴포넌트가 처음 렌더링된 후 실행");
    }

    componentDidUpdate(){
        console.log("컴포넌트 상태가 변경된 후 실행");
    }

    componentWillUnmount(){
        console.log("컴포넌트가 언마운트될때  실행");
    }

    render() {
        return (
            <div>
                <span>message:{this.state.message}</span>
                <button onClick={()=>{this.setState({message:"값변경"})}}>클릭</button>
            </div>
        );
    }
}

export default R05Hooks;
export {R06ClassComponent};