import React, { useState } from 'react';

const R03Event = () => {

    //함수형 컴포넌트에서 state 정의하기
    const [message,setMessage] = useState('');

    const message2='';

    const eventTest01=()=>{
        alert("이벤트실행");
    }

    return (
        <div>
            <h1>이벤트 연습</h1>
            <h2>이벤트로 함수를 전달한다.</h2>
            <button onClick={eventTest01}>클릭(함수전달)</button>

            <h2>이벤트로 state 접근하기</h2>
            <input type="text" onChange={(e)=>{setMessage(e.target.value)}} />
            <span>{message}</span>

            <h2>일반적인 자바스크립트 문법이라면...</h2>
            <input type="text" onChange={(e)=>{message2=e.target.value}} />
            <span>{message2}</span>
        </div>
    );
};

export default R03Event;