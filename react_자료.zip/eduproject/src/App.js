// import logo from './logo.svg';
// import './App.css';

import R01Jsx from "./components/R01Jsx";
import R02Component, { R02ComponentFunc, R02ComponentState } from "./components/R02Component";
import R03Event, { R04Iterator } from "./components/R03Event";
import R05Hooks, { R06ClassComponent } from "./components/R05Hooks";

function App() {
  return (
    <div className="App">
      <R01Jsx />
      <R02Component name='prop01'>클래스형컴포넌트</R02Component>
      <R02ComponentFunc name="prop02" >함수형컴포넌트</R02ComponentFunc>
      <R02ComponentState ></R02ComponentState>
      <R03Event/>
      <R04Iterator/>
      <R05Hooks />
      <R06ClassComponent/>
    </div>
  );
}

export default App;
